package com.ibm.junit5;

public class App
{
    public static void main( final String[] args )
    {
        System.out.println( "args: " + java.util.Arrays.toString( args ) );
    }
}
