# ${name}

${description}

```xml
<dependency>
  <groupId>${project.groupId}</groupId>
  <artifactId>${project.artifactId}</artifactId>
  <version>${project.version}</version>
</dependency>
```


[TODO] add a description of the project and its goals



[TODO] add usage examples
