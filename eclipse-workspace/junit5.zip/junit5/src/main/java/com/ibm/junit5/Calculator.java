package com.ibm.junit5;

public class Calculator {

}
